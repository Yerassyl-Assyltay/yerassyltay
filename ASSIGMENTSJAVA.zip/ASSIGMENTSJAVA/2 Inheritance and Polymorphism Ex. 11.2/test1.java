public class test1{
	public static void main(String[] args) {
	Person p = new Person();
	Student s = new Student();
	Employee e = new Employee();
	Faculty f = new Faculty();
	Stuff sf = new Stuff();
	System.out.println(p.toString());
	System.out.println(s.toString());
	System.out.println(e.toString());
	System.out.println(f.toString());
	System.out.println(sf.toString());
	}
}