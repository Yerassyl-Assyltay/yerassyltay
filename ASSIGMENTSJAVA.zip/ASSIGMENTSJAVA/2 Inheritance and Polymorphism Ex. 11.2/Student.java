public class Student extends Person{
private final String STATUS;
	Student(String name ,String STATUS){
		this.name=name;
		this.STATUS=STATUS;
	}
	Student(){
		this.name="defult";
		this.STATUS="SHKOLNIK";
	}
	public String toString(){
		return "Student class :"+this.name;
	}
}