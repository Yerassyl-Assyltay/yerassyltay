public class Employee extends Person {
private MyDate dateHired;
private int salary;
private String office;
	public Employee(String name, MyDate dateHired,int salary,String office){
	this.name=name;
	this.dateHired=dateHired;
	this.salary=salary;
	this.office=office;
	}
	public Employee(){
	this.name="H";
	this.dateHired=new MyDate();
	this.salary=5000;
	this.office="blmim";
	}

	public String toString(){
	return "Employee class :"+this.name ;
	}
}