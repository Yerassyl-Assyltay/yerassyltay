public class Stuff extends Employee{
private String title;
	public Stuff(String name ,String title){
	this.title=title;
	this.name=name;
	}
	public Stuff(){
	this.title="comander";
	this.name="defult";
	}
	public String toString(){
	return "Stuff class :"+this.name;
	}
}
