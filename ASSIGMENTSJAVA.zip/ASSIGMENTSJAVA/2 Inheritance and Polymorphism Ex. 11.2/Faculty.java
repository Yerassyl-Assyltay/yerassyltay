public class Faculty extends Employee {
    private int officeHours;
    private String rank;

    public Faculty(String name, int officeHours, String rank) {
        this.name = name;
        this.officeHours = officeHours;
        this.rank = rank;
    }

    public Faculty() {
        this.name = "defult";
        this.officeHours = 25;
        this.rank = "rank";
    }

    public String toString() {
        return "Paculty class :" + this.name;
    }
}