public class Person{
public String name;
private String PhoneNumber;
private String addres;
private String emailAddres;
	public Person(String name,String PhoneNumber,String addres,String emailAddres){
	this.name=name;
	this.PhoneNumber=PhoneNumber;
	this.addres=addres;
	this.emailAddres=emailAddres;
	}
	public Person(){
	this.name="defult";
	this.PhoneNumber="56546541";
	this.addres="22 bakerStreet";
	this.emailAddres="donno";
	}
	public String toString(){
	return "Person class :"+this.name;
	}
}