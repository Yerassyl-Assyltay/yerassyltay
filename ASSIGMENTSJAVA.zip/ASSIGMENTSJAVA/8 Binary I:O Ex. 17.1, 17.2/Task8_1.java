package demo2;

import java.io.*;

public class Task8_1 {
    public static void main(String[] args) {

        try (
                PrintWriter pw = new PrintWriter(new FileOutputStream(new File("Exercise17-01.txt"), true));
        ) {
            for (int i = 0; i < 100; i++) {
                pw.print((int)(Math.random() * 100) + " ");
            }
        }
        catch (FileNotFoundException fnfe) {
            System.out.println("Cannot create the file.");
            fnfe.printStackTrace();
        }
    }
}